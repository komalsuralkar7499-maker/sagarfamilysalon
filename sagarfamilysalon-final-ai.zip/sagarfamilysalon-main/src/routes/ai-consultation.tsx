import { createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check, MessageCircle, Sparkles, RotateCcw } from "lucide-react";
import { useMemo, useState } from "react";
import { SALON, SERVICE_PRICES, getPriceTotal, getPricedService, whatsappLink } from "@/lib/salon";

export const Route = createFileRoute("/ai-consultation")({
  head: () => ({
    meta: [
      { title: "AI Beauty Consultation — Sagar Family Salon" },
      {
        name: "description",
        content:
          "Find the right hair, skin or makeup service with Sagar Family Salon's interactive beauty consultation and price estimator.",
      },
    ],
  }),
  component: AIConsultationPage,
});

type Choice = { label: string; value: string; serviceIds: string[] };

const steps: Record<string, { question: string; choices: Choice[] }> = {
  goal: {
    question: "What would you like help with?",
    choices: [
      { label: "💇 Hair", value: "hair", serviceIds: [] },
      { label: "✨ Skin", value: "skin", serviceIds: [] },
      { label: "💄 Makeup", value: "makeup", serviceIds: [] },
      { label: "💍 Bridal", value: "bridal", serviceIds: [] },
      { label: "🤷 Not sure", value: "not-sure", serviceIds: [] },
    ],
  },
  hair: {
    question: "What are you looking for?",
    choices: [
      { label: "✂️ Haircut", value: "haircut", serviceIds: ["womens-haircut"] },
      { label: "🎨 Colour / Balayage", value: "colour", serviceIds: ["balayage"] },
      { label: "🧖 Hair Spa", value: "spa", serviceIds: ["hair-spa"] },
      { label: "✨ Styling", value: "styling", serviceIds: ["blow-dry"] },
    ],
  },
  skin: {
    question: "What's your main skin goal?",
    choices: [
      { label: "💧 Hydration / Glow", value: "glow", serviceIds: ["hydra-facial"] },
      { label: "☀️ Tan / Dullness", value: "tan", serviceIds: ["detan"] },
      { label: "✨ Deep refresh", value: "refresh", serviceIds: ["signature-facial"] },
      { label: "⚡ Quick cleanup", value: "quick", serviceIds: ["cleanup"] },
    ],
  },
  makeup: {
    question: "What is the occasion?",
    choices: [
      { label: "🎉 Party", value: "party", serviceIds: ["party-makeup"] },
      { label: "💍 Engagement", value: "engagement", serviceIds: ["engagement-makeup"] },
      { label: "👁️ Eye-focused", value: "eyes", serviceIds: ["eye-makeup"] },
      { label: "🥻 Makeup + Draping", value: "draping", serviceIds: ["party-makeup", "saree-draping"] },
    ],
  },
  bridal: {
    question: "Choose your bridal requirement",
    choices: [
      { label: "👰 Complete Bridal Look", value: "complete", serviceIds: ["bridal-hd", "bridal-hair", "saree-draping"] },
      { label: "💄 Bridal Makeup", value: "makeup", serviceIds: ["bridal-hd"] },
      { label: "💇 Bridal Hairstyle", value: "hair", serviceIds: ["bridal-hair"] },
      { label: "🤵 Groom Styling", value: "groom", serviceIds: ["groom-styling"] },
    ],
  },
  "not-sure": {
    question: "What's closest to what you want today?",
    choices: [
      { label: "✨ Look fresh & glowing", value: "glow", serviceIds: ["signature-facial"] },
      { label: "💇 Improve my hair", value: "hair", serviceIds: ["hair-spa"] },
      { label: "🎉 Get ready for an event", value: "event", serviceIds: ["party-makeup"] },
      { label: "💬 I'd like expert advice", value: "expert", serviceIds: [] },
    ],
  },
};

function AIConsultationPage() {
  const [current, setCurrent] = useState("goal");
  const [history, setHistory] = useState<string[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [answers, setAnswers] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  const total = useMemo(() => getPriceTotal(selected), [selected]);
  const selectedServices = selected
    .map((id) => getPricedService(id))
    .filter((s): s is NonNullable<typeof s> => Boolean(s));

  const choose = (choice: Choice) => {
    const nextSelected = Array.from(new Set([...selected, ...choice.serviceIds]));
    setSelected(nextSelected);
    setAnswers((v) => [...v, choice.label]);

    if (current === "goal") {
      if (choice.value === "not-sure") {
        setHistory(["goal"]);
        setCurrent("not-sure");
      } else {
        setHistory(["goal"]);
        setCurrent(choice.value);
      }
      return;
    }

    setDone(true);
  };

  const back = () => {
    const previous = history.at(-1);
    if (!previous) return;
    setHistory((h) => h.slice(0, -1));
    setCurrent(previous);
    setDone(false);
  };

  const reset = () => {
    setCurrent("goal");
    setHistory([]);
    setSelected([]);
    setAnswers([]);
    setDone(false);
  };

  const message = `Hi ${SALON.name}! I used the Beauty Consultation.
Recommendation: ${selectedServices.map((s) => s.name).join(", ") || "Expert consultation"}
Estimated total: ₹${total.toLocaleString("en-IN")}
I'd like to book this service.`;

  return (
    <main className="min-h-[calc(100vh-4rem)] bg-background">
      <section className="bg-noir px-4 py-14 text-noir-foreground sm:px-6 sm:py-20">
        <div className="mx-auto max-w-5xl">
          <div className="flex items-center gap-3 text-gold">
            <Sparkles className="h-5 w-5" />
            <span className="text-xs font-semibold uppercase tracking-[0.3em]">AI Beauty Concierge</span>
          </div>
          <h1 className="mt-4 max-w-3xl font-display text-4xl font-bold sm:text-6xl">
            Find your <span className="text-gold-gradient">perfect salon service.</span>
          </h1>
          <p className="mt-5 max-w-2xl text-noir-muted">
            Answer a few simple questions. We'll recommend a service and show an estimated price before you book.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:py-16">
        <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-elegant">
          <div className="h-1 bg-muted">
            <div
              className="h-full bg-primary transition-all duration-500"
              style={{ width: done ? "100%" : current === "goal" ? "25%" : "65%" }}
            />
          </div>

          <div className="p-6 sm:p-10">
            {!done ? (
              <>
                <div className="mb-8">
                  <p className="text-sm font-medium text-primary">Personalized consultation</p>
                  <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">
                    {steps[current]?.question}
                  </h2>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  {(steps[current]?.choices ?? []).map((choice) => (
                    <button
                      key={choice.value}
                      type="button"
                      onClick={() => choose(choice)}
                      className="group flex items-center justify-between rounded-2xl border border-border bg-background p-5 text-left transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:shadow-lg"
                    >
                      <span className="font-medium">{choice.label}</span>
                      <ArrowRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
                    </button>
                  ))}
                </div>

                {history.length > 0 && (
                  <button type="button" onClick={back} className="mt-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                    <ArrowLeft className="h-4 w-4" /> Back
                  </button>
                )}
              </>
            ) : (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-2 text-primary">
                  <Check className="h-5 w-5" />
                  <span className="text-sm font-semibold uppercase tracking-wider">Your recommendation</span>
                </div>

                <h2 className="mt-3 font-display text-3xl font-bold">A look made for you</h2>

                <div className="mt-7 space-y-3">
                  {selectedServices.length ? selectedServices.map((service) => (
                    <div key={service.id} className="flex items-center justify-between rounded-2xl border border-border p-4">
                      <div>
                        <p className="font-semibold">{service.name}</p>
                        <p className="text-xs text-muted-foreground">{service.duration}</p>
                      </div>
                      <p className="font-semibold">₹{service.price.toLocaleString("en-IN")}</p>
                    </div>
                  )) : (
                    <div className="rounded-2xl border border-border p-5">
                      <p className="font-semibold">Personal expert consultation</p>
                      <p className="mt-1 text-sm text-muted-foreground">Our stylist can recommend the right service in person.</p>
                    </div>
                  )}
                </div>

                <div className="mt-6 rounded-2xl bg-noir p-6 text-noir-foreground">
                  <p className="text-sm text-noir-muted">Estimated total</p>
                  <p className="mt-1 font-display text-4xl font-bold text-gold">₹{total.toLocaleString("en-IN")}</p>
                  <p className="mt-2 text-xs text-noir-muted">Demo estimate. Final price may vary after an in-person consultation.</p>
                </div>

                <div className="mt-7 flex flex-wrap gap-3">
                  <a
                    href={whatsappLink(message)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-[1.03]"
                  >
                    <MessageCircle className="h-4 w-4" /> Book on WhatsApp
                  </a>
                  <button type="button" onClick={reset} className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold hover:bg-muted">
                    <RotateCcw className="h-4 w-4" /> Start again
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {SERVICE_PRICES.slice(0, 3).map((s) => (
            <div key={s.id} className="rounded-2xl border border-border/70 bg-card p-5">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Popular</p>
              <p className="mt-2 font-semibold">{s.name}</p>
              <p className="mt-1 text-primary">From ₹{s.price.toLocaleString("en-IN")}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
