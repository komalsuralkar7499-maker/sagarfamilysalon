import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Sparkles, Clock, MessageCircle } from "lucide-react";
import { SALON, SERVICE_CATEGORIES, SERVICE_PRICES, whatsappLink } from "@/lib/salon";
import { BookAppointmentCta, WhatsAppCta } from "@/components/cta-buttons";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services & Pricing — Sagar Family Salon" },
      { name: "description", content: "Explore hair, skin, makeup and bridal services with transparent demo pricing at Sagar Family Salon." },
    ],
    links: [{ rel: "canonical", href: "/services" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org", "@type": "ItemList",
        name: "Services and pricing at Sagar Family Salon",
        itemListElement: SERVICE_PRICES.map((s, i) => ({
          "@type": "ListItem", position: i + 1,
          item: { "@type": "Service", name: s.name, provider: { "@type": "HairSalon", name: SALON.name }, offers: { "@type": "Offer", price: s.price, priceCurrency: "INR" } }
        })),
      }),
    }],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <>
      <section className="bg-noir text-noir-foreground">
        <div className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6 lg:py-20">
          <p className="text-sm font-medium uppercase tracking-[0.3em] text-gold">Our services</p>
          <h1 className="mt-3 font-display text-4xl font-bold sm:text-5xl">
            Beauty, <span className="text-gold-gradient">personalised.</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl leading-relaxed text-noir-muted">
            Explore our services with transparent demo pricing, then let our interactive Beauty Concierge recommend what fits you best.
          </p>
          <Link to="/ai-consultation" className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-[1.03]">
            <Sparkles className="h-4 w-4" /> Try AI Beauty Consultation
          </Link>
        </div>
        <div className="gold-rule mx-auto max-w-6xl" />
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:py-20">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICE_CATEGORIES.map((cat) => {
            const prices = SERVICE_PRICES.filter((s) => s.name && (
              cat.id === "haircut-styling" ? s.category === "hair" && ["Men's Haircut","Women's Haircut","Kids' Haircut","Blow-dry & Styling"].includes(s.name) :
              cat.id === "hair-colour" ? s.category === "hair" && ["Global Hair Colour","Highlights & Balayage","Root Touch-up","Hair Spa & Treatment"].includes(s.name) :
              cat.id === "facial-cleanup" ? s.category === "skin" :
              cat.id === "makeup" ? s.category === "makeup" :
              cat.id === "bridal-makeup" ? s.category === "bridal" :
              cat.id === "hairstyling" ? s.category === "hair" && ["Blow-dry & Styling"].includes(s.name) : false
            ));
            return (
              <article key={cat.id} className="group flex flex-col rounded-3xl bg-card p-6 shadow-elegant transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
                <h2 className="font-display text-2xl font-semibold">{cat.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{cat.description}</p>
                <div className="mt-5 space-y-2">
                  {cat.services.map((name) => {
                    const price = SERVICE_PRICES.find((s) => s.name.toLowerCase() === name.toLowerCase());
                    return <div key={name} className="flex items-center justify-between gap-3 border-b border-border/60 py-2.5 text-sm">
                      <span className="flex items-center gap-2"><Check className="h-4 w-4 shrink-0 text-primary" />{name}</span>
                      {price ? <span className="shrink-0 font-semibold text-primary">₹{price.price.toLocaleString("en-IN")}</span> : <span className="text-xs text-muted-foreground">Ask</span>}
                    </div>;
                  })}
                </div>
                {prices.length > 0 && <p className="mt-4 text-xs text-muted-foreground">Prices shown are demo estimates and may vary by hair length/requirements.</p>}
                <a href={`#${cat.id}`} className="mt-5 text-sm font-semibold text-primary hover:underline">Details & FAQs →</a>
              </article>
            );
          })}
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 pb-16 sm:px-6 lg:pb-20">
        <div className="rounded-3xl border border-primary/20 bg-primary/5 p-6 sm:p-8">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div><p className="font-display text-2xl font-bold">Not sure what to book?</p><p className="mt-1 text-sm text-muted-foreground">Answer a few questions and get a recommendation + estimated price.</p></div>
            <Link to="/ai-consultation" className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"><Sparkles className="h-4 w-4" /> Start Consultation</Link>
          </div>
        </div>

        <div className="mt-12 space-y-12">
          {SERVICE_CATEGORIES.map((cat) => (
            <article key={cat.id} id={cat.id} className="scroll-mt-24 rounded-3xl bg-card p-6 shadow-elegant sm:p-10">
              <h3 className="font-display text-2xl font-bold sm:text-3xl">{cat.title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">{cat.description}</p>
              <ul className="mt-5 grid gap-2.5 sm:grid-cols-2">
                {cat.services.map((s) => <li key={s} className="flex items-start gap-2.5 text-sm"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><span>{s}</span></li>)}
              </ul>
              <h4 className="mt-8 font-display text-lg font-semibold">Frequently asked questions</h4>
              <Accordion type="single" collapsible className="mt-2">
                {cat.faqs.map((faq, i) => <AccordionItem key={faq.question} value={`${cat.id}-${i}`}><AccordionTrigger className="text-left text-sm font-medium">{faq.question}</AccordionTrigger><AccordionContent className="text-sm leading-relaxed text-muted-foreground">{faq.answer}</AccordionContent></AccordionItem>)}
              </Accordion>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link to="/contact" className="inline-flex items-center justify-center rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-gold">Book {cat.title}</Link>
                <a href={whatsappLink(`Hi ${SALON.name}, I want to enquire about ${cat.title}.`)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-2.5 text-sm font-semibold"><MessageCircle className="h-4 w-4" /> WhatsApp</a>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-16 rounded-3xl bg-noir p-8 text-center text-noir-foreground sm:p-12">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Ready for your next look?</h2>
          <p className="mx-auto mt-3 max-w-xl leading-relaxed text-noir-muted">Get a recommendation first, or speak directly with our team.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4"><BookAppointmentCta /><WhatsAppCta /></div>
        </div>
      </section>
    </>
  );
}
